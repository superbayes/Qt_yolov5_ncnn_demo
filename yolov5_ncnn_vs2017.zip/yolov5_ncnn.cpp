﻿// yolov5_ncnn.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#if 0
#头文件
D:\ProgramData\ncnn-20211122-windows-vs2017-shared\x64\include
D:\ProgramData\ncnn-20211122-windows-vs2017-shared\x64\include\ncnn
D:\ProgramData\opencv_3416\vc15\include
D:\ProgramData\opencv_3416\vc15\include\opencv2
D:\VulkanSDK\1.2.198.1\Include
#lib文件
D:\ProgramData\ncnn-20211122-windows-vs2017-shared\x64\lib
D:\ProgramData\opencv_3416\vc15\lib
D:\VulkanSDK\1.2.198.1\Lib

#lib
ncnn.lib
opencv_world3416.lib
vulkan-1.lib
#endif // 0

#include <iostream>
#include <opencv2/opencv.hpp>
#include "YoloV5.h"

int main()
{
	YoloV5* detector;
	detector = new  YoloV5(
		"./model/yolov5s-opt-fp16.param",
		"./model/yolov5s-opt-fp16.bin", true);
	//detector = new  YoloV5(
	//	"./model2_v6.1/yolov5s-sim-opt.param",
	//	"./model2_v6.1/yolov5s-sim-opt.bin", true);
	cv::Mat frame = cv::imread("zidane.jpg", -1);
	detector->detect(frame, 0.7, 0.5);
	detector->draw(frame);
    std::cout << "Hello World!\n";
}
